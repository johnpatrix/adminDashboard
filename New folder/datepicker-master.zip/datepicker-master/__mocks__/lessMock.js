/*
  https://jestjs.io/docs/en/webpack#handling-static-assets
  This mocks the require statement for the less file at
  the top of datepicker.js so that the tests don't fail.
*/

module.exports = {}
